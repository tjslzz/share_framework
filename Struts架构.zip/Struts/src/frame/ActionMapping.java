package frame;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActionMapping {
	//����mapping
	private XMLConfig config;
	private HttpServletRequest request;
	private HttpServletResponse response;
	public ActionMapping(XMLConfig config,HttpServletRequest request,HttpServletResponse response) {
		this.config = config;
		this.request = request;
		this.response = response;
	}
	//ͨ���û���Ҫ�Ļص�jsp������ƥ�䣬������һ��forward����
	public ActionForward findForward(String name){
		return new ActionForward(config.getUri(name),request,response);
	}
}
