package frame;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLConfig {
	//xml����
	private NodeList list;
	private Document dom;
	public XMLConfig(String path) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory buf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = buf.newDocumentBuilder();
		this. dom = db.parse(new File(path));
		this.list = dom.getElementsByTagName("user-case");
	}
	//��ȡ�û�bean
	public String getBean(String name){
		for(int i = 0;i < list.getLength();i++){
			String cmp = dom.getElementsByTagName("user-name").item(i).getFirstChild().getNodeValue();
			if(cmp.matches(name)){
				return dom.getElementsByTagName("user-pattern").item(i).getFirstChild().getNodeValue();
			}
		}
		return null;
	}
	//��ȡת����ַ
	public String getUri(String name){
		for(int i = 0;i < list.getLength();i++){
			String cmp = dom.getElementsByTagName("uri-name").item(i).getFirstChild().getNodeValue();
			if(cmp.matches(name)){
				return dom.getElementsByTagName("uri-pattern").item(i).getFirstChild().getNodeValue();
			}
		}
		return null;
	}
	//��ȡaction����
	public String getAction(String name){
		for(int i = 0;i < list.getLength();i++){
			String cmp = dom.getElementsByTagName("user-name").item(i).getFirstChild().getNodeValue();
			if(cmp.matches(name)){
				return dom.getElementsByTagName("user-action").item(i).getFirstChild().getNodeValue();
			}
		}
		return null;
	}
}
