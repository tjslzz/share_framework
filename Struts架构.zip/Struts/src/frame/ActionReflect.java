package frame;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActionReflect {
	//�������û���action
	private String name;
	public ActionReflect(String name){
		this.name = name;
	}
	//����һ���û�action�����е�excute����
	public ActionForward getAction(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
		@SuppressWarnings("rawtypes")
		Class action = Class.forName(name);
		@SuppressWarnings("unchecked")
		Object obj = action.getConstructor().newInstance();
		for(Method m : action.getDeclaredMethods()){
			return (ActionForward) m.invoke(obj, mapping,form,request,response);
		}
		return null;
	}
}
