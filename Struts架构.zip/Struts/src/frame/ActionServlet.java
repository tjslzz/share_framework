package frame;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		String name = request.getHeader("Referer").substring(request.getHeader("Referer").lastIndexOf("/")+1);
		//һ��jsp���������actionservlet���أ�������Ӧ
		try {
			@SuppressWarnings("deprecation")
			//������Ϣ�̶�
			XMLConfig config = new XMLConfig(request.getRealPath("WEB-INF/Struts.xml"));
			ActionForm form = new ActionForm(config.getBean(name),request);
			ActionMapping mapping = new ActionMapping(config,request,response);
			ActionForward forward = new ActionReflect(config.getAction(name)).getAction(mapping, form, request, response);
			forward.forword();//��Ӧ�û�������
		}catch (Exception e) {e.printStackTrace();}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
