package frame;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActionForward {
	//ת����
	private String uri;
	private HttpServletRequest request;
	private HttpServletResponse response;
	public ActionForward(String name,HttpServletRequest request,HttpServletResponse response){
		this.request = request;
		this.response = response;
		this.uri = name;
	}
	//���ᱻ�û��������乤��ȫ��mapping�����
	public void forword() throws ServletException, IOException{
		this.request.getRequestDispatcher(this.uri).forward(request, response);
	}
}
