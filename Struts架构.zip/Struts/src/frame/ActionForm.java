package frame;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

public class ActionForm {
	//��װmodelʵ�壬�������
	private String name;
	private HttpServletRequest request;
	//�������û���bean
	public ActionForm(String name,HttpServletRequest request){
		this.name = name;
		this.request = request;
	}
	//����һ��object����
	public Object getForm() throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
		@SuppressWarnings("rawtypes")
		Class bean = Class.forName(name);//name���û���JavaBean
		Enumeration<String> e = request.getParameterNames();
		@SuppressWarnings("unchecked")
		//һ��ʵ��
		Object obj = bean.getConstructor().newInstance();
		//����set����set
		while(e.hasMoreElements()){
			String info = e.nextElement();
			String str = request.getParameter(info);
			@SuppressWarnings("unchecked")
			Method m = bean.getMethod("set" + info.substring(0,1).toUpperCase()+info.substring(1), String.class);
			m.invoke(obj, str);
		}
		//���ط������object
		return obj;
	}
}
