package user_case;

public class UserBean {
	private String name;
	private String psw;
	public UserBean(){}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	public String info(){
		return this.getName() + "\t" + this.getPsw();
	}
}
