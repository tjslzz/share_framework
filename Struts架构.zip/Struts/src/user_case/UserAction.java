package user_case;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import frame.Action;
import frame.ActionForm;
import frame.ActionForward;
import frame.ActionMapping;

public class UserAction implements Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws IllegalArgumentException, SecurityException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		UserBean bean = (UserBean) form.getForm();
		if(!bean.getName().isEmpty() && !bean.getPsw().isEmpty()){
			return mapping.findForward("index");
		}
		return null;
	}
}
