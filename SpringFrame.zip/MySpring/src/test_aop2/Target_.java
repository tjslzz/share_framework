package test_aop2;

public class Target_ {
	private String info;
	
	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public void call() {
		System.out.println("	****����Spring AOP 2.0�汾****\n	****"+ this.getInfo()+"****");
	}
	
	public void proxy(){
		System.out.println("	****ָ�����ط�������****");
	}
}
