package test_aop1;

public class Aspect_1 {
	public void before(){
		System.out.println("���ǣ�before...");
	}

}
