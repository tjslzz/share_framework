package test_aop1;

public interface Interface_ {
	String call();
}
