package myframe;

import java.sql.Connection;
import java.sql.DriverManager;

public class SessionFactory {
	//session����
	private Configuration config;
	
	public SessionFactory(Configuration config){
		this.config = config;
	}
	//����һ��hibernate��ܵ�session����������
	public Session openSession(){
		Session session = null;
		try {
			Class.forName(config.getDriverClass());
			Connection conn = DriverManager.getConnection(config.getUrl(),config.getUsername(),config.getPassword());
			session = new SessionImpl(conn,config);
		} catch (Exception e) {e.printStackTrace();
		}
		return session;
	}
	public Configuration getConfig() {
		return config;
	}
	public void setConfig(Configuration config) {
		this.config = config;
	}
	
}
