package myframe;

public class KeyProperty extends Property{
	//����
	private String generator;

	public String getGenerator() {
		return generator;
	}

	public void setGenerator(String generator) {
		this.generator = generator;
	}
}
