package myframe;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Query {
	//����hibernate������ͬ��hibernate��͸����SQL��䣬ͬ����mapƥ��ԭ��
	private String hql;
	private Connection conn;
	private ORM orm;
	private String colum;
	public List<?> getList() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, IllegalArgumentException, InvocationTargetException{
		Statement stmt = this.getConn().createStatement();
		ResultSet rs = stmt.executeQuery(hql);
		this.setColum();
		List<Object> list = new ArrayList<Object>();
		while(rs.next()){
			Object obj = Class.forName(this.getOrm().getClassName()).newInstance();
			Method[] methods = obj.getClass().getMethods();
			for(Method method : methods){
				if(method.getName().equalsIgnoreCase("set" + this.orm.getKeyProperty().getAttrName())){
					Object o = rs.getObject(this.orm.getKeyProperty().getColumName());
					method.invoke(obj, o);
					break;
				}
			}
			
			int count = this.orm.getProperties().size();
			for(int i = 0;i < count;i++){
				Object o = rs.getObject(this.orm.getProperties().get(i).getColumName());
				for(Method method : methods){
					if(method.getName().equalsIgnoreCase("set" + this.orm.getProperties().get(i).getAttrName())){
						method.invoke(obj, o);
					}
				}
			}
			list.add(obj);
		}
		return list;
	}
	//�����ķ������Ѳ�ѯ����������װ��һ���ַ���������ҵ����
	public void setColum() throws SQLException {
		int len = this.orm.getProperties().size();
		StringBuilder sb = new StringBuilder();
		sb.append(this.orm.getKeyProperty().getAttrName()+"\t\t");
		for(int i = 0;i < len;i++){
			sb.append(this.orm.getProperties().get(i).getAttrName()).append("\t");
		}
		this.colum = sb.toString();
	}
	public String getColum() {
		return colum;
	}
	public String gethql() {
		return hql;
	}
	public void sethql(String hql) {
		this.hql = hql;
	}
	public Connection getConn() {
		return conn;
	}
	public void setConn(Connection conn) {
		this.conn = conn;
	}
	public ORM getOrm() {
		return orm;
	}
	public void setOrm(ORM orm) {
		this.orm = orm;
	}
	public Query(ORM orm,Connection conn,String hql) {
		this.hql = hql;
		this.conn = conn;
		this.orm = orm;
	}
	
	


}
