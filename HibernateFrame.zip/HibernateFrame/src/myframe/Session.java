package myframe;

import java.io.Serializable;
import java.sql.SQLException;

public interface Session {
	//Session�ӿڣ��̳нӿڣ����hibernate��ܹ���
	@SuppressWarnings("rawtypes")
	Object load(Class clazz, Serializable oid);
	void close();
	Query createQuery(String hql)throws SQLException;
	Configuration getConfig();
	void save(Object obj)throws Exception;
	void update(Object obj)throws Exception;
	void del(Object obj)throws Exception;
}
