package myframe;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class SessionImpl implements Session{
	//��Ҫ���Ĳ���
	private Connection conn;//����
	private Configuration config;//����
	public SessionImpl(Connection conn,Configuration config){
		this.conn = conn;
		this.config = config;
	}
	public Connection getConn() {
		return conn;
	}
	public void setConn(Connection conn) {
		this.conn = conn;
	}
	public Configuration getConfig() {
		return config;
	}
	public void setConfig(Configuration config) {
		this.config = config;
	}
	//-----------------------------------------------------------------------------------------------------------------------------------------------------
	//�ͷ���Դ
	@Override
	public void close() {
		try {
			if(conn != null && !conn.isClosed()){
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//-----------------------------------------------------------------------------------------------------------------------------------------------------
	@SuppressWarnings("rawtypes")
	@Override
	//load����
	public Object load(Class clazz, Serializable oid) {
		String className = clazz.getName();
		/**
		String[] path = className.split("\\.");
		StringBuilder sb = new StringBuilder();
		sb.append("src");
		for(String s : path){
			sb.append("\\").append(s);
		}
		this.getConfig().getOrms().add(this.getConfig().parse(sb.toString().toLowerCase()  + ".xml"));
		*/
		ORM orm = null;
		for(int i = 0;i < config.getOrms().size();i++){
			
			if(config.getOrms().get(i).getClassName().matches(className)){
				orm = config.getOrms().get(i);
				break;
			}
		}
		//�ҵ���orm֮�󣬴���sql���
		//����ʵ�����
		String sql = selectSql(orm,oid);
		Object obj = query(sql,orm);
		return obj;
	}
	//�����load������select���
	//��ʱ���ٸ�
	private String selectSql(ORM orm,Serializable oid){
		StringBuilder sb = new StringBuilder();
		sb.append("select * ");
		/*
		sb.append("select ").append(orm.getKeyProperty().getColumName());
		for(int i = 0;i < orm.getProperties().size();i++){
			Property p = orm.getProperties().get(i);
			sb.append(",").append(p.getColumName());
		}
		*/
		sb.append("from ").append(orm.getTableName()).append(" where ")
		.append(orm.getKeyProperty().getColumName()).append(" = ").append(oid);
		return sb.toString();
	}
	//ִsql��䣬�����װһ������ʵ�壬Ҫ��xml�ĵ�
	private Object query(String sql,ORM orm){
		Object obj = null;
		try{
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData md = rs.getMetaData();
			obj = Class.forName(orm.getClassName()).newInstance();
			Method[] methods = obj.getClass().getMethods();
			
			while(rs.next()){
				//��ȡ���е���
				for(int i = 0;i < md.getColumnCount();i++){
					String cname = md.getColumnName(i + 1);//���ݿ��������
					String mname = null;//��Ҫƥ���set����
					//����ȥƥ��set����
					//��ƥ������
					if(orm.getKeyProperty().getColumName().equalsIgnoreCase(cname)){
						mname = "set" + orm.getKeyProperty().getAttrName();
					}
					if(mname == null){
						//������������ô���������ֶε���
						for(int j = 0;j < orm.getProperties().size();j++){
							if(orm.getProperties().get(j).getColumName().equalsIgnoreCase(cname)){
								mname = "set" + orm.getProperties().get(j).getAttrName();
								break;
							}
						}
					}
					//��ȡ�����ֵ
					Object val = rs.getObject(cname);
					for(Method method : methods){
						//�������
						if(method.getName().equalsIgnoreCase(mname)){
							method.invoke(obj, val);
						}
					}
				}
			}
			//���ض����load
			return obj;
		}
		catch(Exception e){
			e.printStackTrace();
		}return obj;
	}
	//-----------------------------------------------------------------------------------------------------------------------------------------------------
	@Override
	public Query createQuery(String hql) throws SQLException {
		String className = new String();
		
		String[] str = hql.split(" ");
		StringBuilder sb = new StringBuilder();
		for(int i = 0;i < str.length;i++){
			if(str[i].equalsIgnoreCase("from")){
				className = str[i+1];
				for(int j = i + 2;j < str.length;j++){
					sb.append(str[j]);
				}
			}
		}
		/**
		String[] path = className.split("\\.");
		StringBuilder sb_path = new StringBuilder();
		sb_path.append("src");
		for(String s : path){
			sb_path.append("\\").append(s);
		}
		this.getConfig().getOrms().add(this.getConfig().parse(sb_path.toString().toLowerCase()  + ".xml"));
		*/
		ORM orm = null;
		for(int i = 0;i < config.getOrms().size();i++){
			if(config.getOrms().get(i).getClassName().matches(className)){
				orm = config.getOrms().get(i);
				break;
			}
		}
		hql = "select * from " + orm.getTableName() + sb.toString();
		return new Query(orm,this.getConn(),hql);
	}
	//-----------------------------------------------------------------------------------------------------------------------------------------------------
	@Override
	public void save(Object obj) throws Exception{
		String name = obj.getClass().getName();
		ORM orm = null;
		for(int i = 0;i < config.getOrms().size();i++){
			if(config.getOrms().get(i).getClassName().equalsIgnoreCase(name)){
				orm = config.getOrms().get(i);

			}
		}
		String table = orm.getTableName();
		String[] info = obj.toString().split("\t\t");
		int len = orm.getProperties().size();
		StringBuilder sb = new StringBuilder();
		sb.append("insert into ").append(table).append( "(").append(orm.getKeyProperty().getAttrName());
		for(int i = 0;i < len;i++){sb.append(","+orm.getProperties().get(i).getAttrName());}
		sb.append(")").append(" values (");
		for(int i = 0;i < len;i++){sb.append("?,");}
		sb.append("?);");
		String sql = sb.toString();
		PreparedStatement pStmt = this.conn.prepareStatement(sql);
		for(int i = 0;i <= len;i++){
			pStmt.setObject(i+1,info[i]);
		}
		pStmt.executeUpdate();
	}
	//----------------------------------------------------------------------------------------
	@Override
	public void del(Object obj) throws Exception {
		// TODO Auto-generated method stub
		String name = obj.getClass().getName();
		ORM orm = null;
		for(int i = 0;i < config.getOrms().size();i++){
			if(config.getOrms().get(i).getClassName().equalsIgnoreCase(name)){
				orm = config.getOrms().get(i);

			}
		}
		String table = orm.getTableName();
		String info = obj.toString().split("\t")[0];
		StringBuilder sb = new StringBuilder();
		sb.append("delete from ").append(table).append( " where ").append(orm.getKeyProperty().getAttrName()).append("=").append(info);
		String sql = sb.toString();
		Statement stmt = this.conn.createStatement();
		stmt.executeUpdate(sql);
	}
	@Override
	public void update(Object obj) throws Exception {
		// TODO Auto-generated method stub
		String name = obj.getClass().getName();
		ORM orm = null;
		for(int i = 0;i < config.getOrms().size();i++){
			if(config.getOrms().get(i).getClassName().equalsIgnoreCase(name)){
				orm = config.getOrms().get(i);

			}
		}
		String table = orm.getTableName();
		String[] info = obj.toString().split("\t");
		int len = orm.getProperties().size();
		StringBuilder sb = new StringBuilder();
		sb.append("update ").append(table).append( " set ").append(orm.getKeyProperty().getAttrName()).append("=?");
		for(int i = 0;i < len;i++){sb.append(","+orm.getProperties().get(i).getAttrName()).append("=?");}
		sb.append(" where ").append(orm.getKeyProperty().getColumName()).append(" = ?");
		sb.append(";");
		String sql = sb.toString();
		PreparedStatement pStmt = this.conn.prepareStatement(sql);
		for(int i = 0;i <= len;i++){
			pStmt.setObject(i+1,info[i]);
		}
		pStmt.setObject(len+2, info[0]);
		pStmt.executeUpdate();
	}

}
