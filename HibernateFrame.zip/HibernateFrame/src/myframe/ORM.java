package myframe;

import java.util.ArrayList;
import java.util.List;
//���ݿ�ʵ�壬�׳ƶ����ϵӳ��
public class ORM {
	private String className;//ӳ������
	private String tableName;//����
	private KeyProperty keyProperty;//����
	private List<Property> properties = new ArrayList<Property>();//���������ֶ�
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public KeyProperty getKeyProperty() {
		return keyProperty;
	}
	public void setKeyProperty(KeyProperty keyProperty) {
		this.keyProperty = keyProperty;
	}
	public List<Property> getProperties() {
		return properties;
	}
	public void setProperties(List<Property> properties) {
		this.properties = properties;
	}
	
}
