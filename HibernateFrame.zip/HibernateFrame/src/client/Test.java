package client;

//import myframe.*;

public class Test {
	//������������hibernate�ģ���Ϊhibernate��ԭ�������Զ�Ϊ������bean������bean�Ǳز����ٵ�
	//��Ҫ�ǲ�����bean��ֱ�������JDBC��ܿ��Ժܼ򵥵�ʵ������£���������������̬
        private Integer drugId;
        private String drugName;
        private String unit;
        private Integer alternative;
        private String sideEffects;
        private String drugMethod;

        public int getDrugId(){
                 return drugId;
        }
        public void setDrugId(int drugId){
                 this.drugId = drugId;
        }
        public String getDrugName(){
                 return drugName;
        }
        public void setDrugName(String drugName){
                 this.drugName = drugName;
        }
        public String getUnit(){
                 return unit;
        }
        public void setUnit(String unit){
                 this.unit = unit;
        }
        public int getAlternative(){
                 return alternative;
        }
        public void setAlternative(int alternative){
                 this.alternative = alternative;
        }
        public String getSideEffects(){
                 return sideEffects;
        }
        public void setSideEffects(String sideEffects){
                 this.sideEffects = sideEffects;
        }
        public String getDrugMethod(){
                 return drugMethod;
        }
        public void setDrugMethod(String drugMethod){
                 this.drugMethod = drugMethod;
        }
        public Test(int drugId, String drugName, String unit, int alternative, String sideEffects, String drugMethod){
                 this.drugId = drugId;
                 this.drugName = drugName;
                 this.unit = unit;
                 this.alternative = alternative;
                 this.sideEffects = sideEffects;
                 this.drugMethod = drugMethod;
        }
        public Test(){}
        public String toString(){
        	return this.getDrugId() + "\t\t" +this.getDrugName() + "\t\t    "+ this.getUnit() + "\t\t" + this.getAlternative() + "\t\t" + this.getSideEffects() + "\t\t" + this.getDrugMethod();
        }
}
