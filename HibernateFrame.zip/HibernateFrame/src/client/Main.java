package client;

import java.util.List;

import myframe.Configuration;
import myframe.Query;
import myframe.Session;
import myframe.SessionFactory;

public class Main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception{
		Configuration config = new Configuration().configure("mysql");
		config.getOrms().add(config.parse("src/client/test.xml"));
		SessionFactory sf = config.buildSessionFactory();
		Session s = sf.openSession();
		//Test test = (Test) s.load(Test.class, 1);
		//Test drug = new Test(2, "����", "����", 2, "�ְ�", "����");
		//s.save(drug);
		Query query = s.createQuery("from client.Test");
		List<Test> list = (List<Test>) query.getList();
		System.out.println(query.getColum());
		for(Test test : list){
			System.out.println(test.toString());
		}
	}

}
