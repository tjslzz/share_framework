package servlet;

import java.io.OutputStream;
import java.io.PrintWriter;

public class Response {
	//һ�������
	private OutputStream output;
	public Response() {
	}
	//socket��OutputStream
	public Response(OutputStream output) {
		this.output = output;
	}

	public OutputStream getOutPut(){
		return output;
	}
	//Writer
	public PrintWriter getWriter(){
		return new PrintWriter(this.getOutPut());
	}
}
