package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Request {
	//����
	private String method;//������
	private String uri;//��ַ
	private String item;//Э����Ϣ
	//��ȡsocket��InputStream
	public Request(InputStream input) throws IOException {
		//��ʼ��
		InputStreamReader is = new InputStreamReader(input);
		BufferedReader bf = new BufferedReader(is);
		String info[] = new String[3];
		try{
			info = bf.readLine().split(" ");
		}
		catch(Exception e){
			info[0] = "get";
			info[1] = "";
			info[2] = "Http/1.1";
		}
		finally{
			this.setMethod(info[0]);
			this.setUri(info[1]);
			this.setItem(info[2]);
		}
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	
}
