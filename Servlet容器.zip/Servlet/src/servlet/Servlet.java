package servlet;

public abstract class Servlet {
	//������Servlet����
	public abstract void doGet(Request request,Response response);
	public abstract void doPost(Request request,Response response);
	public void doService(Request request,Response response){
		if(request.getMethod().toLowerCase().matches("get")){
			this.doGet(request, response);
		}
		else{
			this.doPost(request, response);
		}
	}
}
