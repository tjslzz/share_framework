package servlet;

import java.io.PrintWriter;

public class Init extends Servlet{

	//������
	@Override
	public void doGet(Request request, Response response) {
		PrintWriter out = response.getWriter();
		out.println("init......");
		out.println("post:666");
		out.flush();
		out.close();
	}
	@Override
	public void doPost(Request request, Response response) {
		this.doGet(request, response);
	}

}
