package test_case;

import java.io.PrintWriter;

import servlet.Request;
import servlet.Response;
import servlet.Servlet;

public class HttpServlet extends Servlet{

	@Override
	public void doGet(Request request, Response response) {
		PrintWriter out = response.getWriter();
		out.println("<html><head></head>");
		out.println("<body>");
		out.println("Hello World");
		out.println("</body></html>");
		out.flush();
		out.close();
	}

	@Override
	public void doPost(Request request, Response response) {
		this.doGet(request, response);
	}

}
